#!/bin/bash

# инициализируем БД во всех сервисах
docker-compose up -d account-user
docker-compose exec account-user python account_user/migration.py

docker-compose up -d event
docker-compose exec event python event/migration.py

docker-compose up -d pipeline
docker-compose exec pipeline python pipeline/migration.py

docker-compose up -d subscription
docker-compose exec subscription python subscription/migration.py

docker-compose up -d source
docker-compose exec source python source/migration.py

docker-compose up -d integration
docker-compose exec integration python integration/migration.py

docker-compose up -d visual-element
docker-compose exec visual-element python visual_element/migration.py

docker-compose up -d web-buffer
docker-compose exec web-buffer python web_buffer/migration.py

docker-compose up -d clickhouse
poetry run python d_migration/app/main.py

docker-compose stop
