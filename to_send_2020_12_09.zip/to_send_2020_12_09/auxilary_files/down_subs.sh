echo "update subscription: stopped"
psql -h 127.0.0.1 -p 5444 -U postgres -d subscription -c "update subscriptions set status='stopped' where id=1;"

sleep 3
echo "kill ffmpeg"
pkill ffmpeg

echo "stop subscription_1"
docker ps --filter='name=subscription_\d+' -aq | xargs docker rm -f
echo "stop containers wait_data"
docker ps --filter='name=wait_data*' -aq | xargs docker stop | xargs docker rm
echo "stop d_dispatcher_detector dispatcher pipeline-processor redis"
docker-compose stop d-dispatcher-detector
docker-compose stop dispatcher
docker-compose stop pipeline-processor
docker-compose stop web-buffer
docker-compose stop d-temp-storage
docker-compose stop redis

