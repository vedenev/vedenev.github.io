clear
echo "start redis postgres"
docker-compose up -d postgres
docker-compose up -d redis

echo "start nginx_rtmp"
docker-compose up -d nginx_rtmp

echo "start all"
docker-compose up -d event
docker-compose up -d pipeline-processor
docker-compose up -d web-buffer
docker-compose up -d d-temp-storage
docker-compose up -d daemon-file-storage
docker-compose up -d d-dispatcher-detector
docker-compose up -d dispatcher

echo " update subscriptions"
psql -h 127.0.0.1 -p 5444 -U postgres -d subscription -c "update subscriptions set status='configured' where id=1;"

echo "start stream local video"
ffmpeg -f concat -re -i playlist.txt -vcodec libx264 -f flv rtmp://localhost:1935/live/stream


